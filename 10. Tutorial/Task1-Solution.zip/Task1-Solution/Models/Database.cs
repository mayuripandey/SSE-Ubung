namespace BooksService.Models
{
    public class Database
    {
        public Book[] Books { get; set; }
    }
}