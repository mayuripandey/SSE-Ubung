﻿namespace Task1
{
    interface ICalculator
    {
        double Multiply(double lhs, double rhs);
        double Divide(double lhs, double rhs);
    }
}
