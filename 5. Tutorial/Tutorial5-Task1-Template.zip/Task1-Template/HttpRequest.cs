using System.Net;
using System.Threading.Tasks;

namespace SSE
{
    public class HttpRequest
    {
        private HttpRequest() {}

        public static async Task<string> Get(Url url)
        {
            // TODO: resolve DNS
            var ip = "find IP using Dns.GetHostAddressesAsync";

            // construct HTTP request
            var request = "TODO";

            // send TCP request
            return await TcpRequest.Do(ip, url.Port, request);
        }
    }
}