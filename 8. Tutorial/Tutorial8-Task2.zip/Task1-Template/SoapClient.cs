using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Xml.XPath;

namespace SSE
{
    public class SoapClient
    {
        private SoapClient()
        {
        }

        public static async Task<object> Invoke(string url, string ns, string operationName, Dictionary<String,object> parameters)
        {
            
            string message = "<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\"><soap12:Body>\n";
            var parametersStr = "";
            foreach (var parameterName in parameters.Keys)
            {
                var stringBuilder = new StringBuilder();                
                var textWriter = new StringWriter(stringBuilder);
                new XmlSerializer(parameters[parameterName].GetType()).Serialize(textWriter, parameters[parameterName]);

                var reader = XElement.Parse(stringBuilder.ToString()).CreateReader();
                reader.MoveToContent();
                string innerXml = reader.ReadInnerXml();

                parametersStr += string.Format("<{0}>" + innerXml + "</{0}>\n", parameterName);
            }
            message += string.Format("<{0} xmlns=\"{1}\">{2}</{0}>\n", operationName, ns, parametersStr);
            message += "</soap12:Body></soap12:Envelope>";

            var headers = new Dictionary<string, string>();
            headers["content-type"] = "application/soap+xml; charset=utf-8";
            var response = await HttpRequest.Post(url, message, headers);                     
            if(response.StatusCode != "200")
                throw new Exception(string.Format("No response: {0} - {1}",response.StatusCode, response.StatusMessage));

            var doc = new XPathDocument(new StringReader(response.Content));
            var navigator = doc.CreateNavigator();
            return navigator.SelectSingleNode("//*[1]/*[1]/*[1]/*[1]").Value;
        }
    }
}