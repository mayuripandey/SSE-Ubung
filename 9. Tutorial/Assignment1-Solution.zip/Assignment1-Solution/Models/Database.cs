namespace BookmarkService.Models
{
    public class Database
    {
        public Bookmark[] Bookmarks { get; set; }
        public User[] Users { get; set; }
    }
}