namespace BookmarkService.Models
{
    public class Bookmark
    {
    }
}