namespace BookmarkService.Models
{
    public class Database
    {
        public User[] Users { get; set; }
    }
}