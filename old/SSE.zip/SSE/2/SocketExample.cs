﻿// Course Material "Protokolle Verteilte Systeme"
// (c) 2008 by Professur Verteilte und Selbstorganisierende Rechnersysteme, TUC

using System;
using System.Net.Sockets;
using System.Net;

namespace Vsr.Teaching.Pvs.Sample
{
    /// <summary>
    /// A sample program that demonstrates the use of sockets.
    /// </summary>
    class SocketExample
    {       
        /// <summary>
        /// The main program routine.
        /// </summary>        
        static void Main(string[] args)
        {
            // create receive socket, bind and listen
            Socket receiveSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint receiveEndpoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 13000);
            receiveSocket.Bind(receiveEndpoint);
            receiveSocket.Listen(100);

            // create send socket, connect
            Socket sendSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint sendEndpoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 13000);
            sendSocket.Connect(sendEndpoint);

            // send data
            byte[] sendData = System.Text.Encoding.UTF8.GetBytes("x");            
            sendSocket.Send(sendData, 1, 0);

            // accept connections with a new socket
            Socket connectionSocket = receiveSocket.Accept();
            
            // receive data
            byte[] receiveBuffer = new byte[10];
            int receivedBytes = connectionSocket.Receive(receiveBuffer);

            // close sockets
            sendSocket.Shutdown(SocketShutdown.Both);
            sendSocket.Close();
            connectionSocket.Close();

            // output received data and wait
            System.Console.WriteLine(System.Text.Encoding.ASCII.GetString(receiveBuffer, 0, receivedBytes));
            System.Console.ReadLine();

        }

      
    }
}
